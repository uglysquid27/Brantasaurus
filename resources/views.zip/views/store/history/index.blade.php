@extends('store.layouts.main')
@section('content')
<div class="container-fluid bg-secondary mb-5">
    <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
        <h1 class="font-weight-semi-bold text-uppercase mb-3">My History Orders</h1>
        <div class="d-inline-flex">
            <p class="m-0"><a href="/">Home</a></p>
            <p class="m-0 px-2">-</p>
            <p class="m-0">My Orders</p>
        </div>
    </div>
</div>
<div class="container-fluid pt-5">
    <div class="row px-xl-5">
        <div class="col-lg-12 table-responsive mb-5">
            <table class="table table-bordered text-center mb-0">
                <thead class="bg-secondary text-dark">
                    <tr>
                        <th>Tracking Number</th>
                        <th>Total Price</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody class="align-middle">
                    @foreach($orders as $item)
                    <tr>
                        <td class="align-middle"> {{ $item->tracking_num }} </td>
                        <td class="align-middle"> Rp. {{ number_format($item->total_price) }} </td>
                        @if ($item->status == 0)
                        <td scope="row" class="align-middle">Pending</td>
                        @elseif ($item->status == 1)
                        <td scope="row" class="align-middle">Process</td>
                        @elseif ($item->status == 2)
                        <td scope="row" class="align-middle">Shipping</td>
                        @elseif ($item->status == 3)
                        <td scope="row" class="align-middle">Completed</td>
                        @else
                        <td scope="row" class="align-middle">Order Reject</td>
                        @endif
                        <td class="align-middle">
                            <a href=" /my-history/{{ $item->id }}" class="btn btn-sm btn-primary">View</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection